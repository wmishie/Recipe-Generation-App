package com.example.myapplication.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

import android.content.Context
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Recipe::class], version = 1, exportSchema = false)
abstract class RecipeDb : RoomDatabase() {

    abstract fun recipeDao(): LeagueDao

    companion object {
        @Volatile
        private var Instance: RecipeDb? = null

        fun getDatabase(context: Context): RecipeDb {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(context, RecipeDb::class.java, "recipe_db")
                    .build().also { Instance = it }
            }
        }
    }
}

@Dao
interface LeagueDao{
    @Insert
    suspend fun insert(recipe : Recipe)

    @Query("SELECT * from recipe ORDER BY `desc` ASC")
    fun getAllItems(): Flow<List<Recipe>>

    @Query("SELECT * from recipe WHERE  id = :id")
    fun getItem(id: String): Flow<Recipe>
}

@Entity("recipe")
data class Recipe(
    @PrimaryKey
    val id: String,
    val desc : String
)

interface LocalRepository{
    suspend fun insertItem(recipe : Recipe)
    fun getItemStream(id: String): Flow<Recipe?>
    fun getRecipesLocal(): Flow<List<Recipe>>
}

class LocalRepoImpl(private val leagueDao: LeagueDao) : LocalRepository {
    override suspend fun insertItem(recipe: Recipe) = leagueDao.insert(recipe)
    override fun getItemStream(id: String): Flow<Recipe?> = leagueDao.getItem(id)

    override fun getRecipesLocal(): Flow<List<Recipe>> = leagueDao.getAllItems()

}