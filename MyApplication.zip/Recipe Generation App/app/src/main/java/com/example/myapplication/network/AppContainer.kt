package com.example.myapplication.network

import android.content.Context
import com.example.myapplication.local.LocalRepoImpl
import com.example.myapplication.local.LocalRepository
import com.example.myapplication.local.RecipeDb
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit

interface AppContainer {
    val repository: Repository
    val localRepo: LocalRepository
}

class DefaultAppContainer(context: Context) : AppContainer {
    private val baseUrl = " https://8c81-41-89-227-171.ngrok-free.app  "

    private val retrofit: Retrofit = Retrofit.Builder()
        .addConverterFactory(Json.asConverterFactory("application/json".toMediaType()))
        .baseUrl(baseUrl)
        .build()

    /**
     * Retrofit service object for creating api calls
     */
    private val retrofitService: RecipeApi by lazy {
        retrofit.create(RecipeApi::class.java)
    }

    /**
     * DI implementation for Mars photos repository
     */
    override val repository: Repository by lazy {
        RepositoryImpl(retrofitService)
    }

    override val localRepo: LocalRepository by lazy{
        LocalRepoImpl(RecipeDb.getDatabase(context).recipeDao())
    }
}