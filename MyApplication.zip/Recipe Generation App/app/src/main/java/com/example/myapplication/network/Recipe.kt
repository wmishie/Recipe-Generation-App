package com.example.myapplication.network

import kotlinx.serialization.Serializable

@Serializable
data class RecipeRequest(
    val ingredients: String
)

@Serializable
data class RecipeResponse(
    val response: String
)