package com.example.myapplication.ui.auth


import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.network.AuthAuthRepositoryImpl
import com.example.myapplication.network.AuthRepository
import com.example.myapplication.network.Response
import com.example.myapplication.network.StorageService
import com.example.myapplication.network.StorageServiceImpl
import com.example.myapplication.network.UserDetails
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AuthViewModel(
    private val authRepo: AuthRepository = AuthAuthRepositoryImpl(),
    private val storageService: StorageService = StorageServiceImpl(),
) : ViewModel() {

    init {
        reloadUser()
    }

    private var _authState = MutableStateFlow(AuthStateData())
    val authState = _authState.asStateFlow()

    val currentUser: FirebaseUser? = FirebaseAuth.getInstance().currentUser
    private val currentUserId = currentUser?.uid ?: ""
    private var _userData = MutableStateFlow(UserDetails())

    private val _signInResponse = MutableStateFlow<Response<Boolean>>(Response.Idle)

    private var _authEventResponse = Channel<AuthEventResponse>()
    val authEventResponse = _authEventResponse.receiveAsFlow()

    fun signInEmailAndPassword(email: String, password: String) {
        viewModelScope.launch {
            updateLoading(true)
            val response = authRepo.signInEmailAndPassword(email, password)
            when (response) {

                is Response.Failure -> {
                    _authEventResponse.send(AuthEventResponse.Failure(message = response.message))
                }

                is Response.Success -> {
                    _authEventResponse.send(AuthEventResponse.Success)
                }

                Response.Idle -> Unit
            }
            _signInResponse.value = response
        }
        updateLoading(false)
    }

    private fun signUpEmailAndPassword(email: String, password: String) {
        viewModelScope.launch {
            //update state to loading
            val response = authRepo.signUpEmailAndPassword(email, password)
            delay(3000)
            when (response) {
                is Response.Failure -> {
                    onAuthError(response.message)
                }

                Response.Idle -> {

                }

                is Response.Success -> {
                    saveUserToDataBase()
                }

            }
        }
    }

    fun signOut() {
        authRepo.signOut()
    }

    fun saveUserDetails(
        fullName: String,
        phoneNumber: String,
        email: String,
        password: String,
    ) {
        updateLoading(true)
        _userData.update {
            it.copy(
                fullName = fullName,
                phoneNumber = phoneNumber,
                email = email,
            )
        }
        signUpEmailAndPassword(email, password)

    }


    private fun saveUserToDataBase() {
        viewModelScope.launch {
            delay(2000)
            _userData.update {
                it.copy(
                    uid = FirebaseAuth.getInstance().currentUser?.uid ?: "",
                )
            }
            val response = storageService.addUser(_userData.value)
            when (response) {
                true -> {
                    onAuthSuccess()
                }

                false -> {
                    onAuthError("Error during registration, try again")
                }
            }
        }
    }

    private fun onAuthSuccess() {
        updateLoading(false)
        viewModelScope.launch {
            _authEventResponse.send(AuthEventResponse.Success)
        }
    }

    private fun onAuthError(errorMessage: String) {
        updateLoading(false)
        viewModelScope.launch {
            _authEventResponse.send(AuthEventResponse.Failure(errorMessage))
        }
    }

    private fun reloadUser() {
        viewModelScope.launch {
            authRepo.reloadFirebaseUser()
        }
    }

    fun resetPassword(email: String): Boolean {
        viewModelScope.launch {
            val result = authRepo.resetPassword(email)
            _authState.update {
                it.copy(
                    resetPassResult = result
                )
            }
        }
        return _authState.value.resetPassResult
    }

    fun updateLoading(loading: Boolean) {
        _authState.update {
            it.copy(
                isLoading = loading
            )
        }
    }
}


sealed class AuthEventResponse {
    data object Success : AuthEventResponse()
    data class Failure(val message: String) : AuthEventResponse()
}

data class AuthStateData(
    val isLoading: Boolean = false,
    val role: String = "",
    val resetPassResult: Boolean = false,
)


