
package com.example.myapplication.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.local.LocalRepository
import com.example.myapplication.local.Recipe
import com.example.myapplication.network.RecipeRequest
import com.example.myapplication.network.Repository
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class IngredientsViewmodel(
    private val repository: Repository,
    private val localRepo: LocalRepository,

    ) : ViewModel() {
    private val _state = MutableStateFlow(RecipeState())
    val state = _state.asStateFlow()
    private val model = GenerativeModel(
        modelName = "gemini-pro",
        apiKey = "AIzaSyDrWW05eQcUHsKwwfpC_1Z1cM5SjR39AoY"
    )

    init {
        getLocalRecipes()
    }


//    fun getRecipes(ingredients: RecipeRequest) {
//        _state.update {
//            it.copy(isLoading = true)
//        }
//        viewModelScope.launch {
//            try {
//                val response = repository.getRecipes(ingredients)
//                _state.update {
//                    it.copy(response = response.response, isLoading = false)
//                }
//            } catch (e: Exception) {
//                _state.update {
//                    it.copy(response = "Error: ${e.message}", isLoading = false)
//                }
//            }
//        }
//    }

    fun getRecipes(ingredients: RecipeRequest) {
        val query =
            "I am providing you with a list of ingredients, give me a best resipe you can think of: They are ${ingredients.ingredients}"
        viewModelScope.launch {
            _state.update {
                it.copy(isLoading = true)
            }
            try {
                val response = model.generateContent(query).text
                _state.update {
                    it.copy(response = response ?: "Try again, error occurred")
                }

                _state.update {
                    it.copy(isLoading = false)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun saveRecipe(response: String) {
        val randomId = UUID.randomUUID().toString()
        _state.update {
            it.copy(isSaving = true)
        }
        viewModelScope.launch {
            localRepo.insertItem(Recipe(id = randomId, response))
        }
        _state.update {
            it.copy(isSaving = false)
        }
    }

    private fun getLocalRecipes(){
        viewModelScope.launch {
            localRepo.getRecipesLocal(
            ).collectLatest { recipes ->
                _state.update {
                    it.copy(savedRecipes = recipes)
                }
            }
        }
    }
}

data class RecipeState(
    val response: String = "",
    val isLoading: Boolean = false,
    val isSaving: Boolean = false,
    val savedRecipes : List<Recipe> = emptyList()
)

