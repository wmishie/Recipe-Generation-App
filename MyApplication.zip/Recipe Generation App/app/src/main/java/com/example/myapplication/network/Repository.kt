package com.example.myapplication.network

interface Repository {
    suspend fun getRecipes(recipeRequest: RecipeRequest): RecipeResponse
}

class RepositoryImpl(private val recipeApi: RecipeApi) : Repository {
    override suspend fun getRecipes(recipeRequest: RecipeRequest): RecipeResponse {
        return recipeApi.getRecipes(recipeRequest)
    }
}