package com.example.myapplication.ui

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.myapplication.RecipeApp
import com.example.myapplication.ui.home.IngredientsViewmodel

object VmProvider {
    val Factory = viewModelFactory {
        // Initializer for HomeViewModel
        initializer {
            IngredientsViewmodel(
                repository = recipeApp().container.repository,
                localRepo = recipeApp().container.localRepo
            )
        }
    }
}
fun CreationExtras.recipeApp(): RecipeApp =
    (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as RecipeApp)
