package com.example.myapplication.ui.home

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import cafe.adriel.voyager.core.screen.Screen
import com.example.myapplication.local.Recipe
import com.example.myapplication.ui.VmProvider

class Saved : Screen{
    @Composable
    override fun Content() {
        val viewmodel: IngredientsViewmodel = viewModel(factory = VmProvider.Factory)
        val state = viewmodel.state.collectAsState().value
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item{
                Text(text = "Saved Recipes", modifier = Modifier.padding(10.dp))
            }
            items(state.savedRecipes) { recipe ->
                RecipeCard(recipe = recipe)
            }
        }
    }
}

@Composable
fun RecipeCard(modifier: Modifier = Modifier, recipe: Recipe) {
    var expanded by remember {
        mutableStateOf(false)
    }
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(10.dp),
    ) {
        Text(text = recipe.desc, maxLines = if (expanded) Int.MAX_VALUE else 10)
        Button(onClick = {
            expanded = !expanded
        }) {
            if (expanded) {
                Text(text = "Collapse")
            } else {
                Text(text = "Expand")
            }

        }
    }
}