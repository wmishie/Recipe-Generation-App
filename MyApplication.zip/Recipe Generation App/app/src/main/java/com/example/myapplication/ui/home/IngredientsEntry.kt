package com.example.myapplication.ui.home

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.max
import androidx.lifecycle.viewmodel.compose.viewModel
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.Navigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.example.myapplication.network.RecipeRequest
import com.example.myapplication.ui.VmProvider
import kotlinx.coroutines.launch

object IngredientsEntry : Screen {
    @Composable
    override fun Content() {
     Navigator(screen = IngredientsEntryScreen())
    }
}

class IngredientsEntryScreen : Screen {
    @Composable
    override fun Content() {
        val nav = LocalNavigator.currentOrThrow
        val viewmodel: IngredientsViewmodel = viewModel(factory = VmProvider.Factory)
        Scaffold(
            floatingActionButton = {
                FloatingActionButton(modifier = Modifier.padding(2.dp),onClick = {  nav.push(Saved())}) {
                    Text(text = "Saved Recipes", modifier = Modifier.padding(3.dp))
                }
            }
        ) { it ->
            IngredientsEntry(viewmodel = viewmodel, modifier = Modifier.padding(it))
        }
    }
}

@Composable
fun IngredientsEntry(modifier: Modifier = Modifier, viewmodel: IngredientsViewmodel) {
    val state = viewmodel.state.collectAsState().value
    val context = LocalContext.current
    var expanded by remember {
        mutableStateOf(false)
    }
    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .fillMaxSize()
    ) {
        var items by remember { mutableStateOf("") }
        Text(text = " RECIPE GENERATION APP")

        Text(text = "Input your ingredients:")
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = items,
            placeholder = { Text(text = "Input items:") },
            onValueChange = { items = it })
        Button(onClick = {
            if (items.isEmpty()) {
                showToast(
                    context = context,
                    message = "Please input ingredients"
                )
                return@Button
            }
            viewmodel.getRecipes(
                RecipeRequest(ingredients = items)
            )
        }) {
            Text(text = "Generate Recipe!")
        }
        if (state.isLoading) {
            Text("Generating recipe...")
        } else if(state.response.isNotEmpty()) {
            if (expanded) {
                Column {
                    Text(text = state.response)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(onClick = {
                            expanded = !expanded
                        }) {
                            if (expanded) {
                                Text(text = "Collapse")
                            } else {
                                Text(text = "Expand")
                            }

                        }
                    }
                }
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    Text(text = state.response, maxLines = 12)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(onClick = {
                            expanded = !expanded
                        }) {
                            if (expanded) {
                                Text(text = "Collapse")
                            } else {
                                Text(text = "Expand")
                            }

                        }
                        Button(onClick = {
                            viewmodel.saveRecipe(state.response)
                        }) {
                            if (state.isSaving){
                                Text(text = "Saving ...")
                            }else{
                                Text(text = "Save")
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun showToast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}
