package com.example.myapplication.network

data class UserDetails(
    val uid: String = "",
    val fullName: String = "",
    val email: String = "",
    val phoneNumber: String = "",
)