package com.example.myapplication.network

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface RecipeApi{
    @POST("recipe/")
    suspend fun getRecipes(@Body recipeRequest: RecipeRequest): RecipeResponse
}